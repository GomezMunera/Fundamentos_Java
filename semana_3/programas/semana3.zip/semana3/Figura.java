
package semana3;

public class Figura {

 private String nombre;

    public Figura(String n) {
        this.nombre = nombre;
    }

    public void area() {
        System.out.println("El cálculo lo hacen las hijas");
    }
}
