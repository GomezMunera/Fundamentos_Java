
package tienda;


public class Tienda {

   
    public static void main(String[] args) {
        Login usuario1 = new Login();
        usuario1.setVisible(true);
    }
    
}
